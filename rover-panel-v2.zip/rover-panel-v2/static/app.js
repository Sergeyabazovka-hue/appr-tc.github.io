
function openAdd(kind){
  document.getElementById('kind').value = kind;
  document.getElementById('clientName').value = kind === 'rover' ? 'Rover ' : 'Pilot ';
  document.getElementById('addModal').classList.add('show');
  setTimeout(()=>document.getElementById('clientName').focus(),80);
}
function openRename(key,name){
  document.getElementById('renameKey').value=key;
  document.getElementById('renameName').value=name;
  document.getElementById('renameModal').classList.add('show');
}
function closeModal(id){document.getElementById(id).classList.remove('show')}
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('show')}));
document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>{
  document.querySelectorAll('.nav').forEach(x=>x.classList.remove('active')); b.classList.add('active');
  const t=document.getElementById(b.dataset.target); if(t)t.scrollIntoView({behavior:'smooth',block:'start'});
  document.querySelector('.sidebar').classList.remove('open');
}));
document.getElementById('menuBtn').addEventListener('click',()=>document.querySelector('.sidebar').classList.toggle('open'));

async function refreshStats(){
  try{
    const r=await fetch('/api/status',{cache:'no-store'});
    if(!r.ok)return;
    const d=await r.json();
    document.getElementById('updatedAt').textContent=d.updated_at;
    document.getElementById('totalRovers').textContent=d.total_rovers;
    document.getElementById('onlineRovers').textContent=d.online_rovers;
    document.getElementById('offlineRovers').textContent=d.offline_rovers;
    document.getElementById('totalClients').textContent=d.total_clients;
    document.getElementById('traffic').textContent=d.traffic;
    document.getElementById('uptime').textContent=d.uptime;
  }catch(e){}
}
setInterval(refreshStats,10000);
