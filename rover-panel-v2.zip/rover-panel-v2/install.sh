#!/usr/bin/env bash
set -euo pipefail

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
DST=/opt/rover-panel

echo "[1/7] Backup existing panel"
if [ -d "$DST" ]; then
  cp -a "$DST" "${DST}.backup-$(date +%Y%m%d-%H%M%S)"
fi

echo "[2/7] Install files"
mkdir -p "$DST"
cp -a "$SRC_DIR"/app.py "$SRC_DIR"/templates "$SRC_DIR"/static "$SRC_DIR"/requirements.txt "$DST"/
mkdir -p "$DST/generated"
chmod 700 "$DST/generated"

echo "[3/7] Python venv"
python3 -m venv "$DST/venv"
"$DST/venv/bin/pip" install --upgrade pip
"$DST/venv/bin/pip" install -r "$DST/requirements.txt"

echo "[4/7] Environment"
if [ ! -f /etc/rover-panel.env ]; then
  PASS="$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(18))
PY
)"
  cat >/etc/rover-panel.env <<EOF
ADMIN_USER=admin
ADMIN_PASSWORD=$PASS
PANEL_TITLE=Rover Panel
WG_INTERFACE=wg0
WG_NETWORK=10.88.88.0/24
WG_ENDPOINT=
WG_DNS=1.1.1.1
ONLINE_SECONDS=180
EOF
  chmod 600 /etc/rover-panel.env
  echo "NEW ADMIN PASSWORD: $PASS"
else
  echo "Existing /etc/rover-panel.env preserved."
fi

echo "[5/7] Systemd"
cp "$SRC_DIR/rover-panel.service" /etc/systemd/system/rover-panel.service
systemctl daemon-reload
systemctl enable rover-panel
systemctl restart rover-panel

echo "[6/7] Verify"
sleep 2
systemctl --no-pager --full status rover-panel | sed -n '1,16p'

echo "[7/7] Done"
echo "Local panel: http://10.88.88.200:8080"
echo "Before generating NEW client configs, set WG_ENDPOINT in /etc/rover-panel.env and restart rover-panel."
