import json
import os
import re
import secrets
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Depends, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

APP_DIR = Path(os.getenv("ROVER_PANEL_DIR", "/opt/rover-panel"))
DATA_FILE = APP_DIR / "peers.json"
GENERATED_DIR = APP_DIR / "generated"
WG_INTERFACE = os.getenv("WG_INTERFACE", "wg0")
WG_NETWORK = os.getenv("WG_NETWORK", "10.88.88.0/24")
WG_ENDPOINT = os.getenv("WG_ENDPOINT", "")
WG_DNS = os.getenv("WG_DNS", "1.1.1.1")
ONLINE_SECONDS = int(os.getenv("ONLINE_SECONDS", "180"))
ADMIN_USER = os.getenv("ADMIN_USER", os.getenv("PANEL_USER", "admin"))
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", os.getenv("PANEL_PASSWORD", ""))
PANEL_TITLE = os.getenv("PANEL_TITLE", os.getenv("PANEL_NAME", "Rover Panel"))

app = FastAPI(title=PANEL_TITLE)
templates = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))
app.mount("/static", StaticFiles(directory=str(Path(__file__).parent / "static")), name="static")
security = HTTPBasic()


def sh(args, check=True):
    p = subprocess.run(args, capture_output=True, text=True)
    if check and p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout or "command failed").strip())
    return p.stdout.strip()


def auth(credentials: HTTPBasicCredentials = Depends(security)):
    if not ADMIN_PASSWORD:
        raise HTTPException(status_code=503, detail="ADMIN_PASSWORD is not configured")
    ok_user = secrets.compare_digest(credentials.username, ADMIN_USER)
    ok_pass = secrets.compare_digest(credentials.password, ADMIN_PASSWORD)
    if not (ok_user and ok_pass):
        raise HTTPException(status_code=401, detail="Unauthorized", headers={"WWW-Authenticate": "Basic"})
    return credentials.username


def load_meta():
    if not DATA_FILE.exists():
        return {"peers": {}}
    try:
        return json.loads(DATA_FILE.read_text("utf-8"))
    except Exception:
        return {"peers": {}}


def save_meta(data):
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = DATA_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
    os.chmod(tmp, 0o600)
    tmp.replace(DATA_FILE)


def parse_ip(allowed: str) -> str:
    first = (allowed or "").split(",")[0].strip()
    return first.split("/")[0] if first else ""


def auto_kind(ip: str) -> str:
    try:
        last = int(ip.split(".")[-1])
    except Exception:
        return "client"
    if 100 <= last <= 110:
        return "rover"
    if 2 <= last <= 10:
        return "pilot"
    return "client"


def default_name(ip: str, kind: str) -> str:
    last = ip.split(".")[-1] if ip else "?"
    if kind == "rover":
        return f"Rover {last}"
    if kind == "pilot":
        return f"Pilot {last}"
    return f"Client {last}"


def wg_peers():
    out = sh(["wg", "show", WG_INTERFACE, "dump"])
    lines = [x for x in out.splitlines() if x.strip()]
    peers = []
    if len(lines) <= 1:
        return peers
    meta = load_meta().get("peers", {})
    now = int(time.time())
    for row in lines[1:]:
        cols = row.split("\t")
        if len(cols) < 8:
            continue
        pub, _psk, endpoint, allowed, hs, rx, tx, keepalive = cols[:8]
        ip = parse_ip(allowed)
        m = meta.get(pub, {})
        kind = m.get("kind") or auto_kind(ip)
        name = m.get("name") or default_name(ip, kind)
        hs_i = int(hs or "0")
        age = (now - hs_i) if hs_i else None
        online = bool(hs_i and age is not None and age <= ONLINE_SECONDS)
        peers.append({
            "public_key": pub,
            "endpoint": endpoint,
            "allowed_ips": allowed,
            "ip": ip,
            "kind": kind,
            "name": name,
            "handshake": hs_i,
            "handshake_age": age,
            "online": online,
            "rx": int(rx or "0"),
            "tx": int(tx or "0"),
            "keepalive": keepalive,
            "config_file": m.get("config_file"),
            "created_at": m.get("created_at"),
        })
    return peers


def fmt_bytes(n: int) -> str:
    n = int(n or 0)
    units = ["B", "KB", "MB", "GB", "TB"]
    v = float(n)
    for unit in units:
        if v < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(v)} {unit}"
            return f"{v:.1f} {unit}"
        v /= 1024


def fmt_age(sec: Optional[int]) -> str:
    if sec is None:
        return "Ще не підключався"
    if sec < 60:
        return f"{sec} сек. тому"
    if sec < 3600:
        return f"{sec // 60} хв. тому"
    if sec < 86400:
        return f"{sec // 3600} год. тому"
    return f"{sec // 86400} дн. тому"


def uptime_text():
    try:
        seconds = int(float(Path("/proc/uptime").read_text().split()[0]))
        days, rem = divmod(seconds, 86400)
        hours, _ = divmod(rem, 3600)
        return f"{days} дн. {hours} год." if days else f"{hours} год."
    except Exception:
        return "—"


def service_state(name: str) -> bool:
    p = subprocess.run(["systemctl", "is-active", "--quiet", name])
    return p.returncode == 0


def server_public_key() -> str:
    return sh(["wg", "show", WG_INTERFACE, "public-key"])


def next_free_ip(kind: str, peers):
    used = {p["ip"] for p in peers}
    if kind == "rover":
        candidates = [f"10.88.88.{i}" for i in range(100, 111)]
    elif kind == "pilot":
        candidates = [f"10.88.88.{i}" for i in range(2, 11)]
    else:
        raise HTTPException(400, "Невідомий тип клієнта")
    for ip in candidates:
        if ip not in used:
            return ip
    raise HTTPException(409, f"Немає вільних IP для типу {kind}")


def sanitize_name(value: str) -> str:
    value = re.sub(r"[^\w .\-()А-Яа-яІіЇїЄєҐґ]", "", value, flags=re.UNICODE).strip()
    return value[:48] or "Client"


def persist_wg():
    sh(["wg-quick", "save", WG_INTERFACE])


def build_client(kind: str, name: str):
    peers = wg_peers()
    ip = next_free_ip(kind, peers)
    private_key = sh(["wg", "genkey"])
    pub = subprocess.run(["wg", "pubkey"], input=private_key + "\n", capture_output=True, text=True, check=True).stdout.strip()
    psk = sh(["wg", "genpsk"])
    # Write the PSK to a protected temp file and add the peer safely.
    import tempfile
    with tempfile.NamedTemporaryFile("w", delete=False) as tf:
        tf.write(psk + "\n")
        tmp_psk = tf.name
    os.chmod(tmp_psk, 0o600)
    try:
        sh(["wg", "set", WG_INTERFACE, "peer", pub, "preshared-key", tmp_psk, "allowed-ips", f"{ip}/32"])
        persist_wg()
    except Exception:
        subprocess.run(["wg", "set", WG_INTERFACE, "peer", pub, "remove"])
        raise
    finally:
        try:
            os.unlink(tmp_psk)
        except OSError:
            pass

    if not WG_ENDPOINT:
        # Keep the server-side peer active, but refuse to emit a broken client config.
        endpoint_line = "# Endpoint is not configured. Set WG_ENDPOINT in /etc/rover-panel.env"
    else:
        endpoint_line = f"Endpoint = {WG_ENDPOINT}"

    conf = f"""[Interface]
PrivateKey = {private_key}
Address = {ip}/32
DNS = {WG_DNS}

[Peer]
PublicKey = {server_public_key()}
PresharedKey = {psk}
AllowedIPs = {WG_NETWORK}
{endpoint_line}
PersistentKeepalive = 25
"""
    GENERATED_DIR.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^A-Za-z0-9_.-]+", "-", name).strip("-") or kind
    filename = f"{slug}-{ip.replace('.', '-')}.conf"
    path = GENERATED_DIR / filename
    path.write_text(conf, "utf-8")
    os.chmod(path, 0o600)

    data = load_meta()
    data.setdefault("peers", {})[pub] = {
        "name": name,
        "kind": kind,
        "ip": ip,
        "config_file": filename,
        "created_at": datetime.now().isoformat(timespec="seconds"),
    }
    save_meta(data)
    return pub, ip, filename


def view_model():
    peers = wg_peers()
    rovers = [p for p in peers if p["kind"] == "rover"]
    pilots = [p for p in peers if p["kind"] == "pilot"]
    total_rx = sum(p["rx"] for p in peers)
    total_tx = sum(p["tx"] for p in peers)
    for p in peers:
        p["rx_h"] = fmt_bytes(p["rx"])
        p["tx_h"] = fmt_bytes(p["tx"])
        p["handshake_h"] = fmt_age(p["handshake_age"])
    return {
        "title": PANEL_TITLE,
        "peers": peers,
        "rovers": rovers,
        "pilots": pilots,
        "total_clients": len(peers),
        "online_rovers": sum(1 for p in rovers if p["online"]),
        "offline_rovers": sum(1 for p in rovers if not p["online"]),
        "total_rovers": len(rovers),
        "traffic": fmt_bytes(total_rx + total_tx),
        "traffic_rx": fmt_bytes(total_rx),
        "traffic_tx": fmt_bytes(total_tx),
        "uptime": uptime_text(),
        "services": {
            "panel": service_state("rover-panel.service"),
            "wireguard": service_state(f"wg-quick@{WG_INTERFACE}.service"),
            "nginx": service_state("nginx.service"),
        },
        "updated_at": datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
        "wg_endpoint_configured": bool(WG_ENDPOINT),
    }


@app.get("/", response_class=HTMLResponse)
def home(request: Request, _=Depends(auth)):
    vm = view_model()
    return templates.TemplateResponse("index.html", {"request": request, **vm})


@app.get("/api/status")
def api_status(_=Depends(auth)):
    return JSONResponse(view_model())


@app.post("/clients/add")
def add_client(kind: str = Form(...), name: str = Form(...), _=Depends(auth)):
    if kind not in ("rover", "pilot"):
        raise HTTPException(400, "Тип має бути rover або pilot")
    name = sanitize_name(name)
    try:
        _pub, _ip, filename = build_client(kind, name)
    except RuntimeError as e:
        raise HTTPException(500, str(e))
    return RedirectResponse(url=f"/?created={filename}", status_code=303)


@app.post("/clients/rename")
def rename_client(public_key: str = Form(...), name: str = Form(...), _=Depends(auth)):
    name = sanitize_name(name)
    data = load_meta()
    if public_key not in data.get("peers", {}):
        data.setdefault("peers", {})[public_key] = {}
    data["peers"][public_key]["name"] = name
    save_meta(data)
    return RedirectResponse("/", status_code=303)


@app.post("/clients/delete")
def delete_client(public_key: str = Form(...), _=Depends(auth)):
    peers = {p["public_key"]: p for p in wg_peers()}
    if public_key not in peers:
        raise HTTPException(404, "Peer not found")
    sh(["wg", "set", WG_INTERFACE, "peer", public_key, "remove"])
    persist_wg()
    data = load_meta()
    m = data.get("peers", {}).pop(public_key, None)
    save_meta(data)
    if m and m.get("config_file"):
        try:
            (GENERATED_DIR / m["config_file"]).unlink()
        except OSError:
            pass
    return RedirectResponse("/", status_code=303)


@app.get("/clients/{public_key}/config")
def download_config(public_key: str, _=Depends(auth)):
    data = load_meta()
    m = data.get("peers", {}).get(public_key)
    if not m or not m.get("config_file"):
        raise HTTPException(404, "Для цього клієнта конфіг у панелі не збережений")
    path = GENERATED_DIR / m["config_file"]
    if not path.exists():
        raise HTTPException(404, "Файл конфігурації не знайдено")
    return FileResponse(path, filename=path.name, media_type="text/plain")
