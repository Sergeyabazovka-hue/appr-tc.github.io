# Rover Panel V2

Адмін-панель для існуючої WireGuard-мережі 10.88.88.0/24.

## Що вже працює

- сучасний dashboard у стилі узгодженого макета;
- реальний стан WireGuard через `wg show wg0 dump`;
- online/offline за останнім handshake (типово 180 секунд);
- ровери: `10.88.88.100–10.88.88.110`;
- пілоти: `10.88.88.2–10.88.88.10`;
- трафік RX/TX;
- uptime VPS;
- статус `rover-panel`, `wg-quick@wg0`, `nginx`;
- створення нового Rover/Pilot;
- автоматична генерація ключів WireGuard;
- додавання peer до активного `wg0` і `wg-quick save wg0`;
- завантаження згенерованого `.conf`;
- перейменування peer у панелі;
- видалення peer з WireGuard;
- Basic Auth;
- автооновлення статистики кожні 10 секунд.

## Важливо перед установкою

Скрипт робить резервну копію старого `/opt/rover-panel` у `/opt/rover-panel.backup-DATE-TIME`.

Він **не перевстановлює WireGuard** і не змінює адресу сервера `10.88.88.200`.

Якщо `/etc/rover-panel.env` уже є, він зберігається.

## Установка

Розпакуй архів на VPS, перейди в папку та виконай:

```bash
chmod +x install.sh
sudo ./install.sh
```

Потім:

```bash
sudo systemctl status rover-panel --no-pager
```

Відкриття через WireGuard:

```text
http://10.88.88.200:8080
```

## Обов'язково для створення нових клієнтів

Відкрий:

```bash
sudo nano /etc/rover-panel.env
```

Задай реальний endpoint WireGuard, наприклад:

```text
WG_ENDPOINT=YOUR_PUBLIC_IP:51820
```

Після зміни:

```bash
sudo systemctl restart rover-panel
```

## admin.abaz.shop

1. Створи DNS A-record `admin.abaz.shop` на публічну IP-адресу VPS.
2. Скопіюй `nginx-admin.conf.example` у `/etc/nginx/sites-available/admin.abaz.shop`.
3. Увімкни сайт та отримай TLS-сертифікат через certbot.
4. Не відкривай порт 8080 напряму в Інтернет — nginx має проксіювати його до `10.88.88.200:8080`.

## Дані

Локальні назви та посилання на згенеровані конфіги зберігаються у:

```text
/opt/rover-panel/peers.json
/opt/rover-panel/generated/
```

Файли конфігів містять приватні WireGuard-ключі — не публікуй їх у GitHub.
